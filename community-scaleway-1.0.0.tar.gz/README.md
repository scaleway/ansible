# Scaleway Community Collection

This collection contains modules and plugins for Ansible to automate the management of Scaleway infrastructure and services.
